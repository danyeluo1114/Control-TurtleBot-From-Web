#!/usr/bin/env python

import rospy
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
from actionlib_msgs.msg import *
from geometry_msgs.msg import Twist, Pose, Point, Quaternion
from std_msgs.msg import String
from sound_play.libsoundplay import SoundClient

class GoToHome():
    
    def  __init__(self):      
	print "home"
	self.flag = 0
        rospy.on_shutdown(self.shutdown)
        self.move_base = actionlib.SimpleActionClient("/move_base", MoveBaseAction)
        # rospy.loginfo("Wait for the action server to come up")
        self.move_base.wait_for_server(rospy.Duration(5))
        rospy.Subscriber('gohome', String, self.go_home_callback)
        self.pub_ = rospy.Publisher("/charge", String, queue_size=10)
	r = rospy.Rate(10.0)
	while not rospy.is_shutdown():
		if self.flag == 1:
			print "pub charge"
    			self.pub_.publish("charge")
			self.flag = 0
			print self.flag  
		

    def go_home_callback(self, msg):    	
    	goal1 = MoveBaseGoal()
    	goal1.target_pose.header.frame_id = "map"
    	goal1.target_pose.header.stamp = rospy.Time.now()
    	# goal1.target_pose.pose = Pose(Point(-0.628, 0.536, 0.000),Quaternion(0.000, 0.000, 0.000, 1.000))
	goal1.target_pose.pose = Pose(Point(-0.23, 0.0899, 0.000),Quaternion(0.000, 0.000, 0.000, 1.000))
    	self.move_base.send_goal(goal1)
    	success = self.move_base.wait_for_result(rospy.Duration(40))
    	state = self.move_base.get_state()
    	if success and state == GoalStatus.SUCCEEDED:
    		rospy.loginfo("Robot arrives goal ...")
		self.flag = 1
		print self.flag  
    	else:
    		self.move_base.cancel_goal()
    		rospy.loginfo("WARNING! Robot gets lost!")
    
    def shutdown(self):
        if self.goal_sent:
            self.move_base.cancel_goal()
        rospy.loginfo("Stop")
        rospy.sleep(1)

if __name__=="__main__":
	rospy.init_node('gohome')

	
	
	GoToHome()
