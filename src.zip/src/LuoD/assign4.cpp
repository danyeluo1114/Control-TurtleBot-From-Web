#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <math.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Vector3.h>
//#include <move_base_msgs/MoveBaseAction.h>
//#include <actionlib/client/simple_action_client.h>

//typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

static const std::string OPENCV_WINDOW = "Image window";

class ImageConverter
{
  ros::NodeHandle *n;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  ros::Publisher velocity_publisher;
  geometry_msgs::Twist speed;
 
public:
  ImageConverter()
    : it_(*n)
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/usb_cam/image_raw", 10,
      &ImageConverter::imageCb, this);
    image_pub_ = it_.advertise("/image_converter/output_video", 10);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }
  void velocityPublisher()
  {
    velocity_publisher = n->advertise<geometry_msgs::Twist>("cmd_vel_mux/input/navi", 10);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    int row = 0;
    int col = 0;
    int dis_min = 1000000;
    for (int i=0; i < cv_ptr->image.rows; i++) {
        for (int j=0; j < cv_ptr->image.cols; j++) {
            int b = cv_ptr->image.at<cv::Vec3b>(i, j).val[0];
            int g = cv_ptr->image.at<cv::Vec3b>(i, j).val[1];
            int r = cv_ptr->image.at<cv::Vec3b>(i, j).val[2];
            // int dis = pow((r-255)*(r-255) + g*g + b*b, 0.5);
            int dis = (r-255)*(r-255) + g*g + b*b;
            // ROS_INFO("b: %d", b);
            // ROS_INFO("g: %d", g);
            // ROS_INFO("r: %d", r);
            // ROS_INFO("%d", dis);
            if (dis < dis_min) {
                dis_min = dis;
                row = i;
                col = j;
            }
        }
    }
    
    // ROS_INFO("value: %d", cv_ptr->image.at<cv::Vec3b>(0,0).val[0]);
    // ROS_INFO("value: %d", cv_ptr->image.at<cv::Vec3b>(0,0).val[1]);
    // ROS_INFO("value: %d", cv_ptr->image.at<cv::Vec3b>(0,0).val[2]);
    // ROS_INFO("height: %d", msg->height);
    // ROS_INFO("width: %d", msg->width);
    // ROS_INFO_STREAM("encoding: " << msg->encoding);

   
    // ROS_INFO("r: %d", row);
    // ROS_INFO("c: %d", col);

    cv::circle(cv_ptr->image, cv::Point(col, row), 10, CV_RGB(255,0,0));
    ROS_INFO("point(%d, %d)\n", row, col);
    /*
    //tell the action client that we want to spin a thread by default
    MoveBaseClient ac("move_base", true);

    //wait for the action server to come up
    while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
  }

    move_base_msgs::MoveBaseGoal goal;
    goal.target_pose.header.frame_id = "base_link";
    goal.target_pose.header.stamp = ros::Time::now();
    */
    //Identify if the most red pixel is in the left or right side of the screen
    if(col <= msg->width/2)
    {
        ROS_INFO("col: %d\n", col);
    ROS_INFO("msg->width: %d\n", msg->width);
    ROS_INFO("msg->width/2: %d\n", msg->width/2);
        speed.linear.x = 0.5;
        speed.angular.z = -1;
    velocity_publisher.publish(speed);
    }
    else
    {
    ROS_INFO("col: %d\n", col);
    ROS_INFO("msg->width: %d\n", msg->width);
    ROS_INFO("msg->width/2: %d\n", msg->width/2);
        speed.linear.x = 0.5;
        speed.angular.z = 1;
       velocity_publisher.publish(speed);
    }
    //Identify the distance value
    float dist_val = cv_ptr->image.at<float>(col, row);
    if(dist_val > 1)
        //goal.target_pose.pose.position.x = 1.0;
        speed.linear.x = 0.5;
        velocity_publisher.publish(speed);
    //ROS_INFO("Sending goal");
    //ac.sendGoal(goal);
 
    //ac.waitForResult();

    // Update GUI Window
    cv::imshow(OPENCV_WINDOW, cv_ptr->image);
    cv::waitKey(3);
    
    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
  }
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");

  // If it needs to initiate "simple_navigation_goals"?

  ImageConverter ic;
  ic.velocityPublisher();
  ros::spin();
  return 0;
}
